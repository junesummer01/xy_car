find . -name "*.py" -exec chmod +x {} \;
