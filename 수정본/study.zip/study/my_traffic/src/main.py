#!/usr/bin/env python

import rospy
from basic_controller import BasicController
from traffic_light_detector import TrafficLightDetector
from sonic_driver import SonicDriver
from sensor_msgs.msg import Image

if __name__ == '__main__':
    rospy.init_node('main_controller')
    
    controller = BasicController()
    detector = TrafficLightDetector()
    sonic = SonicDriver()

    rospy.wait_for_message("/usb_cam/image_raw/", Image)
    rospy.loginfo("카메라 준비됨")

    rate = rospy.Rate(10)  # 10Hz
    executed = False

    while not rospy.is_shutdown():
        if detector.is_green_light_detected() and not executed:
            rospy.loginfo("🟢 초록불 감지 - 주행 시작")
            controller.drive(0, 60)
            rospy.sleep(1.0)
            controller.drive(0, 0)
            executed = True  # 한 번만 실행되도록 플래그 설정
        if executed==True:
            angle, speed = sonic.get_drive_values()
            controller.drive(angle, speed)
            print(speed)
            rate.sleep()

        rate.sleep()
